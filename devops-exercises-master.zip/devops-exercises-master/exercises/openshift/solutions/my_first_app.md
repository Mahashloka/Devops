## OpenShift - My First Application

### Objectives

1. Create a MySQL application
2. Describe which OpenShift objects were created

### Solution

1. `oc new-app mysql`
2. The following objects were created:
  * ImageStream: 
