# Containerized Web Server

1. Run a containerized web server in the background and bind its port (8080) to a local port
2. Verify the port (8080) is bound
3. Reach the webserver from your local host
