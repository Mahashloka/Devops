## Fork 101 - Solution

1. 2
2. 2
