## Ansible - Update and upgrade APT packages task

1. Write a task to update and upgrade apt packages
