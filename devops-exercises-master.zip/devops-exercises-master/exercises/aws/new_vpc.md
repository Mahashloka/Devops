## AWS VPC - My First VPC

### Objectives

1. Create a new VPC
  1. It should have a CIDR that supports using at least 60,000 hosts
