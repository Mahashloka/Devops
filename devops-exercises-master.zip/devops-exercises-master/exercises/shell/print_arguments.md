## Shell Scripting - Print Arguments

### Objectives

You should include everything mentioned here in one shell script

1. Print the first argument passed to the script
2. Print the number of arguments passed to the script
3. 
