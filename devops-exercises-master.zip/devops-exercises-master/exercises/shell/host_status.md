## It's Alive!

### Objectives

1. Write a script to determine whether a given host is down or up
