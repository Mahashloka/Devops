## Empty Files

### Objectives

1. Write a script to remove all the empty files in a given directory (including nested directories)
