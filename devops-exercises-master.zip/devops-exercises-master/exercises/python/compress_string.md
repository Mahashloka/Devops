## Compress String

1. Write a function that gets a string and compresses it
  - 'aaaabbccc' -> 'a4b2c3'
  - 'abbbc' -> 'a1b3c1'
2. Write a function that decompresses a given string
  - 'a4b2c3' -> 'aaaabbccc'
  - 'a1b3c1' -> 'abbbc'
